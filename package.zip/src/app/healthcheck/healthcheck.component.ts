import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-healthcheck',
  templateUrl: './healthcheck.component.html',
  styleUrls: ['./healthcheck.component.css']
})
export class HealthcheckComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
