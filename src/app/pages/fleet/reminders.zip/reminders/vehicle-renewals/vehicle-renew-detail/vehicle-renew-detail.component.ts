import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicle-renew-detail',
  templateUrl: './vehicle-renew-detail.component.html',
  styleUrls: ['./vehicle-renew-detail.component.css']
})
export class VehicleRenewDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
