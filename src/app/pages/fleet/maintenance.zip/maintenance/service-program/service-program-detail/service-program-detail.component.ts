import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-program-detail',
  templateUrl: './service-program-detail.component.html',
  styleUrls: ['./service-program-detail.component.css']
})
export class ServiceProgramDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
